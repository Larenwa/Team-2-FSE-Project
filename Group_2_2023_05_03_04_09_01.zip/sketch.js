//let button;
let button1;
let button2;
let button3;
let MENU = 0;
let ding;
var score;
var offLineCounter = 0;
var count = 0;
var dingding = false;
var infoguide1 = 0;
var infoguide2 = 0;
var infoguide3 = 0;


let circleButton;
let rectangleButton;
let triangleButton;
//let clear1;

var mode; //determine whether the game has started
var drawingGame;
var tracingExercise;
var shapeColorMatching;
var back1;
var mouseClick;
var points;

// variables to collect mouse X and Y when mousePressed
var x;
var y;

// position of the image to be dragged
let objects = [
  {
    name: "1",
    x: 50,
    y: 205,
    w: 60,
    h: 60,

  },
  {
    name: "2",
    x: 50,
    y: 275,
    w: 60,
    h: 60,
    
  },
    {
    name: "3",
    x: 50,
    y: 350,
    w: 60,
    h: 60,
    
  },
    {
    name: "4",
    x: 50,
    y: 445,
    w: 60,
    h: 60,
    
  },
    {
    name: "5",
    x: 50,
    y: 525,
    w: 60,
    h: 60,
    
  }
]

// transperancy for images
//var z =100;

// variable for the image
var img;
var img2;
var img3;
var img4;
var img5;
// loading up an image
function preload() {
  img = loadImage("assets/1.png");
  img2 = loadImage("assets/2.png");
  img3 = loadImage("assets/3.png");
  img4 = loadImage("assets/4.png");
  img5 = loadImage("assets/5.png");
}

function setup() {
  ding = loadSound('assets/Correct_Sound_Effect.mp3');
  
  mode = 0; //initially the game has not started
  drawingGame = 0;
  tracingExercise = 0;
  shapeColorMatching = 0;
  score = 0;
  back1 = 0;
  back2 = 0;
  draw2 = 0;
  draw3 = 0;
  points = [];
  createCanvas(600, 400);
  background(500, 190, 100);
  strokeWeight(2);
  background(220);
  
  //buttons
  //button1
  button1 = createButton('✩ Drawing Game ✩');
  button1.style('background-color', 'yellow');
  button1.size(200, 50);
  button1.position(200,110);
  button1.mousePressed(game1); 
  button1.hide();
  //info
  info1 = createButton('?');
  info1.style('background-color', 'lightgreen');
  info1.size(40, 40);
  info1.position(430,115);
  info1.mousePressed(information1); 
  info1.hide();
  
  info2 = createButton('?');
  info2.style('background-color', 'lightgreen');
  info2.size(40, 40);
  info2.position(430,205);
  info2.mousePressed(information2); 
  info2.hide();
  
    info3 = createButton('?');
  info3.style('background-color', 'lightgreen');
  info3.size(40, 40);
  info3.position(430,305);
  info3.mousePressed(information3); 
  info3.hide();
  //button2
  button2 = createButton('✩ Tracing Exercise ✩');
  button2.style('background-color', 'pink');
  button2.size(200, 50);
  button2.position(200,200);
  button2.mousePressed(game2); 
  button2.hide();
  //button3
  button3 = createButton('✩ Shape Matching ✩');
  button3.style('background-color', 'orange');
  button3.size(200, 50);
  button3.position(200,300);
  button3.mousePressed(game3); 
  button3.hide();
  
  //backButtons
  //backButton1
  backButton1 = createButton('Return');
  backButton1.style('background-color', 10);
  backButton1.size(60, 50);
  backButton1.position(645,50);
  backButton1.mousePressed(return1);
  backButton1.hide();
  
  //backButton2
  backButton2 = createButton('Return');
  backButton2.style('background-color', 10);
  backButton2.size(60, 50);
  backButton2.position(645,50);
  backButton2.mousePressed(game1);
  backButton2.hide();
  
  //backButton3
  backButton3 = createButton('Return');
  backButton3.style('background-color', 10);
  backButton3.size(60, 50);
  backButton3.position(645,50);
  backButton3.mousePressed(return2);
  backButton3.hide();
  
  //backButton4
  backButton4 = createButton('Return');
  backButton4.style('background-color', 10);
  backButton4.size(60, 50);
  backButton4.position(645,50);
  backButton4.mousePressed(game2);
  backButton4.hide();
  
  //circleButton
  circleButton = createButton('⚘ Circle ⚘');
  circleButton.style('background-color', 'rgb(255,197,91)');
  circleButton.size(300, 50);
  circleButton.position(250,150);
  circleButton.mousePressed(() => draw1 = true);
  circleButton.hide();
  //rectangleButton
  rectangleButton = createButton('⚘ Rectangle ⚘');
  rectangleButton.style('background-color', 'rgb(246,246,189)');
  rectangleButton.size(300, 50);
  rectangleButton.position(250,250);
  rectangleButton.mousePressed(() => draw2 = true);
  rectangleButton.hide();
  //triangleButton
  triangleButton = createButton('⚘ Triangle ⚘');
  triangleButton.style('background-color', 'pink');
  triangleButton.size(300, 50);
  triangleButton.position(250,350);
  triangleButton.mousePressed(() => draw3 = true);
  triangleButton.hide();
  
  //clear button
  clearButton = createButton('Clear');
  clearButton.style('background-color', 10);
  clearButton.size(60, 50);
  clearButton.position(100,50);
  clearButton.mousePressed(clear1);
  clearButton.hide(); 
  
  //Completed button
  completeButton = createButton('Finish');
  completeButton.style('background-color', 10);
  completeButton.size(60, 50);
  completeButton.position(645, 750);
  completeButton.mousePressed(complete);
  completeButton.hide();
  
  //1 button
  oneButton = createButton('❀ Number 1 ❀');
  oneButton.style('background-color', 'rgb(255,197,91)');
  oneButton.size(300, 50);
  oneButton.position(250,150);
  oneButton.mousePressed(() => draw1 = true);
  oneButton.hide();
  //N button
  nButton = createButton('❀ Letter N ❀');
  nButton.style('background-color', 'rgb(246,246,189)');
  nButton.size(300, 50);
  nButton.position(250,250);
  nButton.mousePressed(() => draw2 = true);
  nButton.hide();
  //W button
  wButton = createButton('❀ Letter W ❀');
  wButton.style('background-color', 'pink');
  wButton.size(300, 50);
  wButton.position(250,350);
  wButton.mousePressed(() => draw3 = true);
  wButton.hide();
  
}

      function information1() {
    infoguide1 = 1;
  tracingExercise = 0;
  shapeColorMatching = 0;
  draw1 = 0;
  draw2 = 0;
  draw3 = 0;
  mode = 1;
  //hide buttons
  button1.hide();
  button2.hide();
  button3.hide();
  backButton2.hide();
  completeButton.hide();
  //navigate to drawing game
    }
      function information2() {
    infoguide2 = 1;
  tracingExercise = 0;
  shapeColorMatching = 0;
  draw1 = 0;
  draw2 = 0;
  draw3 = 0;
  mode = 1;
  //hide buttons
  button1.hide();
  button2.hide();
  button3.hide();
  backButton2.hide();
  completeButton.hide();
  //navigate to drawing game
    }
      function information3() {
    infoguide3 = 1;
  tracingExercise = 0;
  shapeColorMatching = 0;
  draw1 = 0;
  draw2 = 0;
  draw3 = 0;
  mode = 1;
  //hide buttons
  button1.hide();
  button2.hide();
  button3.hide();
  backButton2.hide();
  completeButton.hide();
  //navigate to drawing game
    }
function game1() {
  drawingGame = 1;
  tracingExercise = 0;
  shapeColorMatching = 0;
  draw1 = 0;
  draw2 = 0;
  draw3 = 0;
  mode = 1;
  //hide buttons
  button1.hide();
  button2.hide();
  button3.hide();
  backButton2.hide();
  completeButton.hide();
  //navigate to drawing game
  draw();
}
function game2() {
  drawingGame = 0;
  shapeColorMatching = 0;
  tracingExercise = 1;
  draw1 = 0;
  draw2 = 0;
  draw3 = 0;
      //hide buttons
      clearButton.hide();
      backButton4.hide();
      completeButton.hide();
      button1.hide();
      button2.hide();
      button3.hide();
      //navigate to tracing exercise
      draw();
}
function game3() {
  drawingGame = 0;
  tracingExercise = 0;
  shapeColorMatching = 1;
      //hide buttons
      button1.hide();
      button2.hide();
      button3.hide();
    //navigate to shape/color matching game
    draw();
}
function return1() {
  drawingGame = 0;
  tracingExercise = 0;
  shapeColorMatching = 0;
  infoguide1 = 0;
   infoguide2 = 0;
   infoguide3 = 0;
  //back1 = 1;
  mode = 0;
  backButton1.hide();
  backButton2.hide();
  clearButton.hide();
  circleButton.hide();
  rectangleButton.hide();
  triangleButton.hide();
  completeButton.hide();
  draw();
}

function return2() {
  drawingGame = 0;
  tracingExercise = 0;
  shapeColorMatching = 0;
  //back1 = 1;
  mode = 0;
  backButton1.hide();
  backButton3.hide();
  clearButton.hide();
  oneButton.hide();
  nButton.hide();
  wButton.hide();
  completeButton.hide();
  draw();
}

function clear1() {
  clear();
  noStroke();
  //remove();
  
  location.reload(false);
  score = score;
  clearButton.hide();
  backButton2.hide();
  completeButton.hide();
  //navigate to new window
  draw();
}
function complete() {
  drawingGame = 0;
  tracingExercise = 0;
  offLineCounter = 0;
  
  //hide buttons
  clearButton.hide();
  backButton4.hide();
  backButton3.hide();
  backButton2.hide();
  backButton1.hide();
  completeButton.hide();
  
  if (shapeColorMatching == 0) {
    var inRange = dist(mouseX, mouseY,400, 480)<= 480;
    var inBounds = mouseX > 130 && mouseX < 700 && mouseY > 30 && mouseY < 800; 
    //for(var i in points) {
      //if(mouseIsPressed) {
      if(mouseIsPressed && offLineCounter <= 500) {
        ding.play();
        score = score + 1;
    } else {
      score = score;
    } 
  }
  shapeColorMatching = 0;
  
  if (dingding == true) {
    ding.play();
    dingding = false;
  }
  
  mode = 0;
  draw();
}


function mousePressed() {
  if (shapeColorMatching != 1) {
    mouseClick = [mouseX, mouseY];
    var coord = {};
    coord.x = mouseX;
    coord.y = mouseY;
  }
} 
function setLineDash(list) {
  drawingContext.setLineDash(list);
}


function draw() {
  clear();
  //print(mouseX, mouseY);


  if(mode == 0) {
    createCanvas(600, 400);
    background(500, 190, 100);
    textSize(40);
    fill(0);
    text('Choose a Game to Start', 90, 80);
    textSize(20);
    fill(10);
    text('Score: '+ score, 20, 250);
    
    button1.show();
    button2.show();
    button3.show();
    info1.show();
    info2.show();
    info3.show();
            //drawing flowers
    
    drawFlower(100,30,color(300, 100, 200), color(250, 250, 250));
    
    drawFlower(50,80, color(255, 60, 60), color(250, 250, 250));
    
    drawFlower(70,150, color(255, 250, 10), color(250, 250, 250));
    
    drawFlower(580,300, color(255, 60, 60), color(250, 250, 250));
    
    drawFlower(580,370, color(300, 100, 200), color(250, 250, 250));
    
    drawFlower(510,390, color(255, 200, 10), color(250, 250, 250));
  }
  
    if(back1 == 1) {
      createCanvas(600, 400);
      background(500, 190, 100);
      textSize(40);
      fill(255);
      text('Choose a Game to Start', 90, 90);
      backButton1.hide();
      circleButton.hide();
      rectangleButton.hide();
      triangleButton.hide();
      button1.show();
      button2.show();
      button3.show();
    }
    if (infoguide1 == 1){
      info1.hide();
       info2.hide();
       info3.hide();
    createCanvas(800, 800);
    background('#fae'); 
    //background(230);
    //title
    textSize(40);
    fill(10);
    text('⋆ ˚｡⋆୨୧Drawing Game Help୨୧⋆｡˚ ⋆', 100, 150);
      text('Click which shape you want to draw.', 100, 260);
      text('Then, click and drag your left mouse', 100, 330);
      text('button to begin drawing.', 100, 380);
      text('Trace the white dotted lines.', 100, 450);
              text('Click "Clear" to reset your drawing.', 100, 520);
               text('When you are finished, click Finish.', 100, 590);
         text('Click "Return" to return to the main', 100, 660);
         text('menu.', 100, 710);
        text('✧･ﾟ: *✧･ﾟ:*✧･ﾟ: *✧･ﾟ:*･ﾟ*✧･ﾟ･ﾟ: *✧･ﾟ:*', 100, 790);
      backButton1.show();
  }
      if (infoguide2 == 1){
      info1.hide();
          info2.hide();
       info3.hide();
    createCanvas(800, 800);
    background('#fae'); 
    //background(230);
    //title
    textSize(40);
    fill(10);
    text('⋆ ˚｡⋆୨୧Tracing Exercise Help୨୧⋆｡˚ ⋆', 80, 150);
      text('Click which letter or number to trace.', 100, 260);
      text('Then, click and drag your left mouse', 100, 330);
      text('button to begin drawing.', 100, 380);
      text('Trace the white dotted lines.', 100, 450);
        text('Click "Clear" to reset your drawing.', 100, 520);
               text('When you are finished, click Finish.', 100, 590);
         text('Click "Return" to return to the main', 100, 660);
         text('menu.', 100, 710);
        text('✧･ﾟ: *✧･ﾟ:*✧･ﾟ: *✧･ﾟ:*･ﾟ*✧･ﾟ･ﾟ: *✧･ﾟ:*', 100, 790);
      backButton1.show();
  }
      if (infoguide3 == 1){
      info1.hide();
          info2.hide();
       info3.hide();
    createCanvas(800, 800);
    background('#fae'); 
    //background(230);
    //title
    textSize(40);
    fill(10);
    text('⋆ ˚｡⋆୨୧Shape Matching Help୨୧⋆｡˚ ⋆', 100, 150);
      text('Click and drag a shape to move it.', 100, 260);
      text('Place the shape on top of the ', 100, 330);
      text('matching word.', 100, 380);
       text('When you are finished, click Finish.', 100, 450);
         text('Click "Return" to return to the main', 100, 520);
         text('menu.', 100, 570);
        text('✧･ﾟ: *✧･ﾟ:*✧･ﾟ: *✧･ﾟ:*･ﾟ*✧･ﾟ･ﾟ: *✧･ﾟ:*', 100, 660);
      backButton1.show();
  }
  //drawing game
  if(drawingGame == 1) {
    //hide buttons
    button1.hide();
    button2.hide();
    button3.hide();
    backButton2.hide();
    clearButton.hide();
    info1.hide();
    info2.hide();
    info3.hide();
    //show buttons
    circleButton.show();
    rectangleButton.show();
    triangleButton.show();
    //create new canvas
    createCanvas(800, 800);
    background('#fae'); 
    //background(230);
    //title
    textSize(40);
    fill(10);
    text('* ˚ ✦Drawing Game✦ ˚ *', 180, 90);
    //display back/return button
    backButton1.show(); 
    
        //drawing flowers
    
    drawFlower(150,50,color(255, 204, 0), color(250, 250, 250));
    
    drawFlower(100,90, color(255, 60, 60), color(250, 250, 250));
    
    drawFlower(120,150, color(255, 150, 10), color(250, 250, 250));
    
    drawFlower(670,470, color(255, 60, 60), color(250, 250, 250));
    
    drawFlower(620,520, color(255, 204, 0), color(250, 250, 250));
    
    drawFlower(550,500, color(255, 150, 10), color(250, 250, 250));
    
    //circle
    if(draw1) {
      //hide buttons
      circleButton.hide();
      rectangleButton.hide();
      triangleButton.hide();
      backButton1.hide();
      //show buttons
      backButton2.show();
      clearButton.show();
      completeButton.show();
      //new canvas
      createCanvas(800, 800);
      background('orange');
      //title
      textSize(40);
      fill(10);
      text('*＊✿❀ Circle ❀✿＊*', 215, 90);
    //draw circle
      push();
      stroke(255);
      strokeWeight(20);
      noFill();
      setLineDash([60, 50]);
      ellipse(400, 480, 500);
      pop();
    //allow user to draw on canvas  
      beginShape();
  for(var i in points) {
    // grab the point by index
   
    var coord = points[i];
    stroke('pink');
    strokeWeight(20);
    noFill();
    curveVertex(coord.x, coord.y);
  
      
      
    }
  }else if(draw2) {
      //hide buttons
      circleButton.hide();
      rectangleButton.hide();
      triangleButton.hide();
      backButton1.hide();
      //show buttons
      backButton2.show();
      clearButton.show();
      completeButton.show();
      createCanvas(800, 800);
      background('rgb(245,233,166)');
      //title
      textSize(40);
      fill(10);
      text('*＊✿❀ Rectangle ❀✿＊*', 170, 90);
      //creates rectangle outline
      push();
      stroke(255);
      strokeWeight(20);
      noFill();
      setLineDash([60, 50]);
      stroke(51);
      rect(200, 200, 400, 480);
      pop();
      
      //allow user to draw on canvas
      beginShape(); 
  for(var i in points) {
    var coord = points[i];
    stroke('orange');
    strokeWeight(20);
    noFill();
    //curveVertex(coord.x, coord.y, pmouseX, pmouseY);
    curveVertex(coord.x, coord.y);
  }
	endShape(); 
}
    //if user selects triangle button
    else if(draw3) {
      circleButton.hide();
      rectangleButton.hide();
      triangleButton.hide();
      backButton1.hide();
      backButton2.show();
      clearButton.show();
      completeButton.show();
      createCanvas(800, 800);
      background('pink');
      //title
      textSize(40);
      fill(10);
      text('*＊✿❀ Triangle ❀✿＊*', 210, 90);
      //creates outline of triangle
      push();
      stroke(255);
      strokeWeight(20);
      noFill();
      setLineDash([60, 50]);
      stroke(51);
      triangle(160, 600, 420, 160, 688, 600);
      pop();
      //allow user to draw on canvas
      beginShape(); 
  for(var i in points) {
    var coord = points[i];
    stroke('yellow');
    strokeWeight(20);
    noFill();
    curveVertex(coord.x, coord.y);
  }
	endShape(); 
      //have console notify user if mouse is inside or outside circle  
      let distance = dist(mouseX, mouseY, 400, 480);
      if (distance < 490 / 2) {
        console.log("My mouse is in the shape!")
        offLineCounter++;
      }
      if (distance > 515 / 2) {
        console.log("My mouse is not in the shape!")  
        offLineCounter++;
        push();
        stroke(255);
        strokeWeight(12);
        line(mouseX, mouseY, pmouseX, pmouseY); 
        pop();
      }
      //draw on canvas
      if (mouseIsPressed) {
        push();
        stroke(255);
        strokeWeight(6);
        pop();
    } else {
      push();
      noStroke();
      pop();
    } 
  }
    //HEREHEREHRHER
	endShape();
  }
    //if rectangle button is selected
    
  //tracing exercise
  if(tracingExercise == 1) {
    //hide buttons
    button1.hide();
    button2.hide();
    button3.hide();
        info1.hide();
    info2.hide();
    info3.hide();
    //create new canvas
    createCanvas(800, 800);
    background('pink');
    //title
    textSize(40);
    fill(10);
    text('*.·.✧Tracing Exercise✧.·.*', 165, 90);
    //display back/return button
    oneButton.show();
    nButton.show();
    wButton.show();
    backButton3.show();
    
            //drawing flowers
    
    drawFlower(150,50,color(255, 204, 0), color(250, 250, 250));
    
    drawFlower(100,90, color(255, 60, 60), color(250, 250, 250));
    
    drawFlower(120,150, color(255, 150, 10), color(250, 250, 250));
    
    drawFlower(670,470, color(255, 60, 60), color(250, 250, 250));
    
    drawFlower(620,520, color(255, 204, 0), color(250, 250, 250));
    
    drawFlower(550,500, color(255, 150, 10), color(250, 250, 250));
    
    if (draw1) {
      oneButton.hide();
      nButton.hide();
      wButton.hide();
      backButton1.hide();
      backButton4.show();
      clearButton.show();
      completeButton.show();
      createCanvas(800, 800);
      background(255,197,91);
      //title
      textSize(40);
      fill(10);
      text('*＊✿❀ Number 1 ❀✿＊*', 180, 90);
      //creates 1 outline
      push();
      stroke(255);
      strokeWeight(20);
      noFill();
      setLineDash([60, 50]);
      stroke(51);
      //draw 1 using lines
      line(400, 160, 400, 650);
      line(400, 160, 300, 250);
      pop();
      
      //allow user to draw on canvas
      beginShape(); 
      for(var i in points) {
        var coord = points[i];
        stroke('orange');
        strokeWeight(20);
        noFill();
        //curveVertex(coord.x, coord.y, pmouseX, pmouseY);
        curveVertex(coord.x, coord.y);
      }
	  endShape(); 
      
      
    } else if (draw2) {
      oneButton.hide();
      nButton.hide();
      wButton.hide();
      backButton1.hide();
      backButton4.show();
      clearButton.show();
      completeButton.show();
      createCanvas(800, 800);
      background(246,246,189);
      //title
      textSize(40);
      fill(10);
      text('*＊✿❀ Letter N ❀✿＊*', 200, 90);
      
      //creates N outline
      push();
      stroke(255);
      strokeWeight(20);
      noFill();
      setLineDash([60, 50]);
      stroke(51);
      //draw N using lines
      line(200, 160, 200, 650);
      line(200, 160, 600, 650)
      line(600, 160, 600, 650);
      pop();
      
      //allow user to draw on canvas
      beginShape(); 
      for(var i in points) {
        var coord = points[i];
        stroke('orange');
        strokeWeight(20);
        noFill();
        //curveVertex(coord.x, coord.y, pmouseX, pmouseY);
        curveVertex(coord.x, coord.y);
      }
	  endShape(); 
      
    } else if (draw3) {
      oneButton.hide();
      nButton.hide();
      wButton.hide();
      backButton1.hide();
      backButton4.show();
      clearButton.show();
      completeButton.show();
      createCanvas(800, 800);
      background('pink');
      //title
      textSize(40);
      fill(10);
      text('*＊✿❀ Letter W ❀✿＊*', 200, 90);
      
      //creates W outline
      push();
      stroke(255);
      strokeWeight(20);
      noFill();
      setLineDash([60, 50]);
      stroke(51);
      //draw W using lines
      line(200, 160, 300, 650);
      line(300, 650, 400, 160);
      line(400, 160, 500, 650);
      line(500, 650, 600, 160);
      pop();
      
      //allow user to draw on canvas
      beginShape(); 
      for(var i in points) {
        var coord = points[i];
        stroke('orange');
        strokeWeight(20);
        noFill();
        //curveVertex(coord.x, coord.y, pmouseX, pmouseY);
        curveVertex(coord.x, coord.y);
      }
	  endShape(); 
      
    }
    
  }
  //shape/color matching game
  if(shapeColorMatching == 1) {
    //hide buttons
    button1.hide();
    button2.hide();
    button3.hide();
    completeButton.show();
        info1.hide();
    info2.hide();
    info3.hide();
    clearButton.show();
    
    //create new canvas
    createCanvas(800, 800);
    background('#F6C375 ');
    //title
    textSize(40);
    fill(10);
    text('*•.¸♡Shape Matching Game♡¸.•*', 120, 150);
    //display back/return button
    backButton1.show();

    rect(530, 200, 150, 60)
    rect(530, 280, 150, 60)
    rect(530, 360, 150, 60)
    rect(530, 440, 150, 60)
    rect(530, 520, 150, 60)
    fill('white')
    textSize(25);
    text('Circle', 570, 220, 300)
    text('Square', 565, 300, 300)
    text('Star', 580, 380, 300)
    text('Heart', 575, 460, 300)
    text('Triangle', 560, 540, 300)
              image(img2, objects[1].x , objects[1].y, objects[1].w, objects[1].h);
    image(img, objects[0].x, objects[0].y, objects[0].w, objects[0].h);
    image(img3, objects[2].x , objects[2].y, objects[2].w, objects[2].h);
    image(img4, objects[3].x , objects[3].y, objects[3].w, objects[3].h);
    image(img5, objects[4].x , objects[4].y, objects[4].w, objects[4].h);
    if (count == 5){
      score = score + 1;
      dingding = true;
    }
    
    //score
    //correct!
    if ((objects[2].x > 500) && (objects[2].x < 640)) {
      if ((objects[2].y > 260) && (objects[2].y < 300)) {
        fill('rgb(122, 230, 122)');
        text("Correct!", 390, 320);
        count++;
      }
    }
          if ((objects[3].x > 500) && (objects[3].x < 640)) {
      if ((objects[3].y > 180) && (objects[3].y < 220)) {
        fill('rgb(122, 230, 122)');
        text("Correct!", 390, 240);
        count++;

      }
    }
            if ((objects[4].x > 500) && (objects[4].x < 640)) {
      if ((objects[4].y > 330) && (objects[4].y < 380)) {
        fill('rgb(122, 230, 122)');
        text("Correct!", 390, 400);
        count++;

      }
    }

              if ((objects[0].x > 500) && (objects[0].x < 640)) {
      if ((objects[0].y > 400) && (objects[0].y < 470)) {
        fill('rgb(122, 230, 122)');
        text("Correct!", 390, 480);
        count++;

      }
    }
                if ((objects[1].x > 500) && (objects[1].x < 640)) {
      if ((objects[1].y > 500) && (objects[1].y < 540)) {
        fill('rgb(122, 230, 122)');
        text("Correct!", 390, 560);
        count++;

      }
    }
  }
}

function mouseDragged() {
  if (shapeColorMatching != 1) {
    // creates object
    var coord = {};
    coord.x = mouseX;
    coord.y = mouseY;
    // adds point to array
    points.push(coord);
  } else {
      objects.forEach((object) => {
      if (mouseX > object.x && mouseX < object.x + object.w && mouseY > object.y && mouseY < object.y + object.h) {
            object.x = mouseX - object.w / 2;
            object.y = mouseY - object.h / 2;
      }

    })
  }
}
function drawFlower(x, y, col, col2) {
  //flower
  fill(col);
  ellipse(x,y,20,20);
  ellipse(x-15,y+5,20,20);
  ellipse(x-25,y-5,20,20);
  ellipse(x-17,y-20,20,20);
  ellipse(x,y-15,20,20);
  fill(col2);
  ellipse(x-12,y-7,22,22);
}